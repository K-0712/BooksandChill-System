<?php
session_start();
require_once 'Customer.php';

if (!isset($_SESSION['user']['name']) || !isset($_SESSION['user']['password'])) {
    die("User not logged in.");
}

$customer = new Customer($_SESSION['user']['password'], $_SESSION['user']['name']);
$customer->review($_POST['rating'], $_POST['comment'], $_POST['title']);
