<?php
session_start();
require_once 'User.php'; // Include the User class

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $type = $_POST['type'];
    $name = $_POST['name'];
    $password = $_POST['password'];

    // Call the login method from User class
    User::login($type, $name, $password);
}
?>
