<?php
require_once 'utils.php';

class Orders {
    private $file = 'json/orders.json';
    private $bookID;
    private $customerID;
    private $price;
    private $address;
    private $payment;

    public function __construct($bookID, $customerId, $price, $address = '', $payment = 'Cash on Delivery') {
        $this->bookID = $bookID;
        $this->customerID = $customerId;
        $this->price = $price;
        $this->address = $address;
        $this->payment = $payment;
    }

    public function saveOrder() {
        $orders = $this->getOrders();
        if (!is_array($orders)) $orders = [];
        $orders[] = [
            'bookID' => $this->bookID,
            'customerID' => $this->customerID,
            'price' => $this->price,
            'address' => $this->address,
            'payment' => $this->payment,
            'status' => 'Pending',
            'date' => date('Y-m-d H:i:s')
        ];
        write_json($this->file, $orders);
    }

    public function getOrders() {
        return read_json($this->file) ?? [];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookId = $_POST['bookID'] ?? '';
    $customerId = $_POST['customerID'] ?? '';
    $price = $_POST['price'] ?? '';
    $address = $_POST['address'] ?? '';
    $payment = 'Cash on Delivery'; // hardcoded here, or you can get from form if needed

    if (empty($bookId) || empty($customerId) || empty($price) || empty($address)) {
        header("Location: error.php");
        exit();
    }

    $order = new Orders($bookID, $customerID, $price, $address, $payment);
    $order->saveOrder();

    // You may want to remove the item from cart here if you keep cart logic

    header("Location: customer_dashboard.php");
    exit();
}
?>
