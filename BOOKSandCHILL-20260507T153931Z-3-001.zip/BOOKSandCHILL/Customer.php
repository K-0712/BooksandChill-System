<?php
require_once 'User.php';
require_once 'utils.php';

class Customer extends User {
    private $customerID;
    private $customerFile = 'json/customers.json';

    public function __construct($password, $name) {
    // Default values for unused fields since only name/password are used post-login
    parent::__construct($name, '', '', '', $password, 'customer');

    // Load or create customerID
    $this->customerID = $this->loadOrCreateCustomerID();
}


    private function loadOrCreateCustomerID() {
        $customers = read_json($this->customerFile);

        // Search for existing user
        foreach ($customers as $customer) {
            if ($customer['name'] === $this->name) {
                return $customer['customerID'];
            }
        }

        // If not found, generate new ID and save
        $newID = uniqid('cust_');
        $customers[] = [
            'name' => $this->name,
            'customerID' => $newID
        ];

        write_json($this->customerFile, $customers);
        return $newID;
    }

    public function getCustomerID() {
        return $this->customerID;
    }

    public function purchase($bookID) {
        $books = read_json('json/books.json');
        $book = current(array_filter($books, fn($b) => $b['bookID'] === $bookID));
        
        if ($book) {
            $orders = read_json('json/orders.json');
            $orders[] = [
                'bookID' => $bookID,
                'title' => $book['title'],
                'customerID' => $this->customerID,
                'customerName' => $this->name,
                'date' => date('Y-m-d H:i:s'),
                'status' => 'Pending'
            ];
            write_json('json/orders.json', $orders);
        }
    }

    public function setCustomerID($id) {
    $this->customerID = $id;
}
    
    
    public function review($rating, $comment, $title, $bookId) {
    $reviews = read_json('json/reviews.json');
    $reviews[] = [
        'CustomerID' => $this->customerID,
        'NameOfReviewer' => $this->name,
        'Ratings' => $rating,
        'Comments' => $comment,
        'ReviewDate' => date('Y-m-d'),
        'BookTitle' => $title,
        'BookID' => $bookId,
    ];

    write_json('json/reviews.json', $reviews);

    header("Location: customer_dashboard.php");
    exit();
}

}

?>
