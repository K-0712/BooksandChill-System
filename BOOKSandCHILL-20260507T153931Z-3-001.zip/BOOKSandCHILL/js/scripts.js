// js/scripts.js

document.addEventListener("DOMContentLoaded", () => {
    const forms = document.querySelectorAll("form");
  
    forms.forEach(form => {
      form.addEventListener("submit", (e) => {
        const requiredInputs = form.querySelectorAll("[required]");
        let valid = true;
  
        requiredInputs.forEach(input => {
          if (!input.value.trim()) {
            valid = false;
            input.style.border = "1px solid red";
          } else {
            input.style.border = "";
          }
        });
  
        if (!valid) {
          e.preventDefault();
          alert("Please fill in all required fields.");
        }
      });
    });
  });
  