<?php
require_once 'utils.php';

class User {
    protected $name;
    protected $address;
    protected $sex;
    protected $nationality;
    protected $password;
    protected $type;

    public function __construct($name, $address, $sex, $nationality, $password, $type) {
        $this->name = $name;
        $this->address = $address;
        $this->sex = $sex;
        $this->nationality = $nationality;
        $this->password = password_hash($password, PASSWORD_DEFAULT);
        $this->type = $type;
    }

    public function register() {
        $file = 'json/users.json';

        if (file_exists($file)) {
            $users = read_json($file);
        } else {
            $users = [];
        }

        $users[] = [
            'name' => $this->name,
            'address' => $this->address,
            'sex' => $this->sex,
            'nationality' => $this->nationality,
            'password' => $this->password,
            'type' => $this->type
        ];

        file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));
    }

    public static function handleRegistration() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $address = $_POST['address'];
            $sex = $_POST['sex'];
            $nationality = $_POST['nationality'];
            $password = $_POST['password'];
            $type = $_POST['type'];

            $user = new User($name, $address, $sex, $nationality, $password, $type);
            $user->register();

            header("Location: index.html");
            exit();
        }
    }

    public static function login($type, $name, $password) {
        $file = 'json/users.json';
        $data = read_json($file);

        foreach ($data as $user) {
            if ($user['type'] === $type && $user['name'] === $name && password_verify($password, $user['password'])) {
                session_start();
                $_SESSION['user'] = [
                    'name' => $name,
                    'type' => $type,
                    'password' => $password  // store plain password only if needed (prefer token/session id for real-world apps)
                ];

                if ($type === 'customer') {
                    header("Location: customer_dashboard.php");
                } else {
                    header("Location: employee_dashboard.php");
                }
                exit();
            }
        }

        echo "<p style='color:red; font-family: sans-serif;'>Invalid login credentials. <a href='login.html'>Try again</a></p>";
    }

    public function logout() {
        session_start();
        session_destroy();
        header("Location: index.html");
        exit();
    }
}
?>
