<?php
session_start();
require_once 'customer.php';

$books = json_decode(file_get_contents('json/books.json'), true);
$reviews = json_decode(file_get_contents('json/reviews.json'), true);

$book_id = $_GET['book_id'] ?? null;
if (!$book_id) {
    die("Book not found.");
}

$book = null;
foreach ($books as $b) {
    if ($b['id'] === $book_id) {
        $book = $b;
        break;
    }
}

if (!$book) {
    die("Book not found.");
}

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user']['name']) || !isset($_SESSION['user']['password'])) {
        die("User not logged in.");
    }

    $customerName = $_SESSION['user']['name'];
    $customersList = json_decode(file_get_contents('json/customers.json'), true);

    // Find matching customer by name
    $matchedCustomer = null;
    foreach ($customersList as $cust) {
        if ($cust['name'] === $customerName) {
            $matchedCustomer = $cust;
            break;
        }
    }

    if (!$matchedCustomer) {
        die("Customer not found.");
    }

    $customerID = $matchedCustomer['customerID'];
    $customer = new Customer($_SESSION['user']['password'], $customerName);
    $customer->setCustomerID($customerID);
    $customer->review($_POST['rating'], $_POST['comment'], $book['title'], $book_id);  
}
$reviews = json_decode(file_get_contents('json/reviews.json'), true);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book Review - <?= htmlspecialchars($book['title']) ?> - Books & Chill</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="top-nav">
  <a href="logout.php" class="btn">Logout</a>
</div>
<div class="container">
  <div class="book-review-content">
    <h1><?= htmlspecialchars($book['title']) ?></h1>
    <p><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
    <p><strong>Year:</strong> <?= $book['year'] ?></p>
    <p><strong>Price:</strong> ₱<?= $book['price'] ?></p>
    <img src="images/<?= $book['cover'] ?>" alt="Book Cover" style="max-width: 200px;">

    <h2>Submit a Review</h2>
    <form action="book_review.php?book_id=<?= urlencode($book_id) ?>" method="POST">
      <select name="rating" required>
        <option value="">Rating</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
      </select>
      <textarea name="comment" placeholder="Your review..." required></textarea>
      <button type="submit">Submit Review</button>
    </form>

    <h2>Reviews for <?= htmlspecialchars($book['title']) ?></h2>
    <?php
    foreach ($reviews as $review) {
        if ($review['BookTitle'] === $book['title']) {
            echo "<div class='review'>";
            echo "<p><strong>" . htmlspecialchars($review['NameOfReviewer']) . "</strong> (" . $review['Ratings'] . "/5)</p>";
            $maskedID = substr($review['CustomerID'], 0, 7) . str_repeat('*', strlen($review['CustomerID']) - 7);
            echo "<p><small style='opacity: 0.4;'>Customer ID: " . htmlspecialchars($maskedID) . "</small></p>";
            echo "<p>" . htmlspecialchars($review['Comments']) . "</p>";
            echo "<p><small>Reviewed on " . $review['ReviewDate'] . "</small></p>";
              if (isset($review['BookID'])) {
                  echo "<p><small>Book ID: " . htmlspecialchars($review['BookID']) . "</small></p>";
              }
            echo "</div>";
        }
    }
    ?>
  </div>
</div>
</body>
</html>
