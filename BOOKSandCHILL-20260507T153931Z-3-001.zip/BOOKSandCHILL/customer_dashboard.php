<?php
session_start();
require_once 'utils.php';

if (!isset($_SESSION['user']['name'])) {
  $_SESSION['user']['name'] = 'Guest';
}

$books = read_json('json/books.json') ?? [];
$reviews = read_json('json/reviews.json') ?? [];
$categories = read_json('json/categories.json') ?? [];

$selectedCategoryID = $_GET['category'] ?? null;

if ($selectedCategoryID) {
  $books = array_filter($books, function ($book) use ($selectedCategoryID) {
    return $book['category_id'] === $selectedCategoryID;
  });
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Customer Dashboard - Books & Chill</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="top-nav">
    <a href="logout.php" class="btn">Logout</a>
  </div>

  <div class="container">
    <div class="dashboard-content">
      <h1>Browse & Buy Books</h1>

      <!-- Category Filter Dropdown -->
      <form method="GET">
        <select name="category" id="category" onchange="this.form.submit()">
          <option value="">All Categories</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= htmlspecialchars($cat['category_id']) ?>" <?= ($selectedCategoryID === $cat['category_id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($cat['category_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </form>

      <div class="books">
        <?php if (count($books) > 0): ?>
          <?php foreach ($books as $book): ?>
            <div class="book">
              <div onclick="showReviews('<?= htmlspecialchars($book['title'], ENT_QUOTES) ?>')">
                <?php $cover = !empty($book['cover']) ? $book['cover'] : 'default.jpg'; ?>
                <img src="images/<?= htmlspecialchars($cover) ?>" alt="Book Cover">
                <h3><?= htmlspecialchars($book['title']) ?></h3>
                <p>Author: <?= htmlspecialchars($book['author']) ?></p>
                <p>Year: <?= htmlspecialchars($book['year']) ?></p>
                <p>Price: ₱<?= htmlspecialchars($book['price']) ?></p>
              </div>

              <form class="Add" action="add_to_cart.php" method="POST" onclick="event.stopPropagation();">
                <input type="hidden" name="title" value="<?= htmlspecialchars($book['title']) ?>">
                <input type="hidden" name="price" value="<?= htmlspecialchars($book['price']) ?>">
                <input type="hidden" name="bookID" value="<?= htmlspecialchars($book['bookID']) ?>">
                <button type="submit">Add to Cart</button>
              </form>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p>No books available in this category.</p>
        <?php endif; ?>
      </div>

      <!-- Order list -->
      <?php $orders = read_json('json/orders.json') ?? []; ?>
      <h2>Order Status</h2>
      <ul>
        <?php foreach ($orders as $order): ?>
          <li><?= htmlspecialchars($order['title']) ?> — <?= htmlspecialchars($order['status'] ?? 'Pending') ?></li>
        <?php endforeach; ?>
      </ul>

      <!-- Cart -->
      <?php
      $cart = read_json('json/cart.json') ?? [];
      $customer = $_SESSION['user']['name'];
      ?>
      <div class="cart-container">
        <h2>☆ YOUR CART ☆</h2>

        <?php foreach ($cart as $index => $item): ?>
          <?php if ($item['customer'] === $customer): ?>
            <div class="cart-item">
              <div class="details">
                <h4><?= htmlspecialchars($item['title']) ?></h4>
                <p>₱<?= htmlspecialchars($item['price']) ?></p>
                <p>Added on: <?= htmlspecialchars(date('F j, Y g:i A', strtotime($item['date']))) ?></p>
              </div>
              <div class="actions">
                <button onclick="openOrderForm(
            '<?= addslashes($item['title']) ?>',
            '<?= $item['price'] ?>',
            '<?= addslashes($item['bookID'] ?? '') ?>'
          )">Place Order</button>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>



      <!-- Review Form -->
      <div class="review-form-container">
        <h3>Hi, <?= htmlspecialchars($_SESSION['user']['name']) ?>!</h3>

        <h2>Write a Review</h2>
        <p style="font-style: italic; color: #555;">Please see the reviews of the books by clicking on the book. Thank you.</p>
        <form action="review.php" method="POST">
          <select class="rating" name="rating" required>
            <option value="">Rating</option>
            <?php for ($i = 1; $i <= 5; $i++): ?>
              <option value="<?= $i ?>"><?= $i ?></option>
            <?php endfor; ?>
          </select>

          <select class="title" name="title" required>
            <option value="">Select Book Title</option>
            <?php foreach ($books as $book): ?>
              <option value="<?= htmlspecialchars($book['title']) ?>"><?= htmlspecialchars($book['title']) ?></option>
            <?php endforeach; ?>
          </select>

          <textarea class="thoughts" name="comment" placeholder="Share your thoughts about this book..." required></textarea>
          <button type="submit">Submit Review</button>
        </form>
      </div>

      <!-- Ads -->
      <div class="ads">
        <h2>Sponsored Ads</h2>
        <p>Check out our latest deals and promos!</p>
        <img src="images/Ads.png" alt="Promotional Banner" style="max-width:100%; height:auto;">
      </div>
    </div>
  </div>

  <!-- Reviews Modal -->
  <div id="reviewModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeModal()">&times;</span>
      <h2>Book Reviews</h2>
      <ul id="reviewList"></ul>
    </div>
  </div>

  <script>
    function showReviews(bookTitle) {
      var reviews = <?= json_encode($reviews) ?>;
      var reviewList = document.getElementById('reviewList');
      reviewList.innerHTML = '';

      var filteredReviews = reviews.filter(function(review) {
        return review.BookTitle === bookTitle;
      });

      if (filteredReviews.length > 0) {
        filteredReviews.forEach(function(review) {
          var maskedID = review.CustomerID.substring(0, 7) + '*'.repeat(review.CustomerID.length - 7);
          var li = document.createElement('li');
          li.innerHTML = '<strong>' + review.NameOfReviewer + '</strong> (' + review.Ratings + '/5): "' + review.Comments + '" – ' + review.ReviewDate +
            '<br><em>Customer ID: ' + maskedID + '</em>';
          reviewList.appendChild(li);
        });
      } else {
        var li = document.createElement('li');
        li.textContent = 'No reviews available for this book.';
        reviewList.appendChild(li);
      }

      document.getElementById('reviewModal').style.display = "block";
    }

    function closeModal() {
      document.getElementById('reviewModal').style.display = "none";
    }

    function openOrderForm(title, price, bookID) {
      document.getElementById('orderBookTitle').value = title;
      document.getElementById('orderPrice').value = price;
      document.getElementById('orderBookId').value = bookID;
      document.getElementById('orderFormModal').style.display = 'block';
    }

    function closeOrderForm() {
      document.getElementById('orderFormModal').style.display = 'none';
    }
  </script>

  <div id="orderFormModal" class="modal" style="display:none;">
    <div class="modal-content">
      <span class="close" onclick="closeOrderForm()">&times;</span>
      <h2>Complete Your Order</h2>
      <form action="place_order.php" method="POST">
        <input type="hidden" name="title" id="orderBookTitle" required>
        <input type="hidden" name="bookID" id="orderBookId" required>
        <p>Name: <?= htmlspecialchars($_SESSION['user']['name']) ?></p>
        <label>Address: <input type="text" name="address" required></label><br>
        <input type="number" name="price" id="orderPrice" readonly required><br>
        <p>Payment Method: Cash on Delivery</p>
        <button type="submit">Submit Order</button>
      </form>
    </div>
  </div>

  <script>
    function openOrderForm(title, price, bookID) {
      document.getElementById('orderBookTitle').value = title;
      document.getElementById('orderPrice').value = price;
      document.getElementById('orderBookId').value = bookID;
      document.getElementById('orderFormModal').style.display = 'block';

    }

    document.addEventListener('keydown', function(event) {
      if (event.key === 'Escape') closeModal();
    });

    function closeOrderForm() {
      document.getElementById('orderFormModal').style.display = 'none';
    }
  </script>



</body>

</html>