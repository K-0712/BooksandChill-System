<?php
$books = json_decode(file_get_contents('json/books.json'), true);
$orders = json_decode(file_get_contents('json/orders.json'), true);
$categories = json_decode(file_get_contents('json/categories.json'), true);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Dashboard - Books & Chill</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body class="employee-dashboard">
  <div class="top-nav">
    <a href="logout.php" class="btn">Logout</a>
  </div>

  <div class="container">
    <h1>Inventory Management</h1>

    <!-- Add Book Form -->
    <form action="Inventory.php" method="POST" enctype="multipart/form-data" onsubmit="return validateCategory();">
      <input type="hidden" name="action" value="add">
      <input type="text" name="title" placeholder="Book Title" required>
      <input type="text" name="author" placeholder="Author" required>
      <input type="text" name="year" placeholder="Year" required>
      <input type="text" name="price" placeholder="Price" required>
      <input type="file" name="cover" required>

      <label for="category_select"><strong>Select Category</strong></label>
      <select id="category_select" onchange="handleCategoryChange(this.value)">
        <option value="">-- Choose Category --</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?= htmlspecialchars($cat['category_id']) ?>|<?= htmlspecialchars($cat['category_name']) ?>">
            <?= htmlspecialchars($cat['category_name']) ?>
          </option>
        <?php endforeach; ?>
        <option value="new">+ Add New Category</option>
      </select>

      <input type="text" id="category_id" name="category_id" placeholder="Category ID" readonly required>
      <input type="text" id="category_name" name="category_name" placeholder="Category Name" readonly required>

      <input class="btn" type="submit" value="Add Book">
    </form>

    <script>
      function handleCategoryChange(value) {
        const idField = document.getElementById('category_id');
        const nameField = document.getElementById('category_name');

        if (value === 'new') {
          idField.value = '';
          nameField.value = '';
          idField.readOnly = false;
          nameField.readOnly = false;
        } else if (value) {
          const [id, name] = value.split('|');
          idField.value = id;
          nameField.value = name;
          idField.readOnly = true;
          nameField.readOnly = true;
        } else {
          idField.value = '';
          nameField.value = '';
          idField.readOnly = true;
          nameField.readOnly = true;
        }
      }

      function validateCategory() {
        const categorySelect = document.getElementById('category_select');
        const id = document.getElementById('category_id').value.trim();
        const name = document.getElementById('category_name').value.trim();

        if (categorySelect.value === 'new' && (!id || !name)) {
          alert("Please fill in both Category ID and Name for the new category.");
          return false;
        }
        return true;
      }
    </script>

    <!-- Display Orders -->
    <h2>Customer Orders (<?= count($orders) ?>)</h2>
    <ul class="order-list">
      <?php foreach ($orders as $i => $order): ?>
        <li>
          <strong><?= htmlspecialchars($order['customer']) ?></strong> (Customer ID: <?= htmlspecialchars($order['customerID'] ?? 'N/A') ?>)
          ordered
          <strong><?= htmlspecialchars($order['title']) ?></strong> (Book ID: <?= htmlspecialchars($order['bookID'] ?? 'N/A') ?>)
          <br>
          <em>Address:</em> <?= htmlspecialchars($order['address'] ?? 'N/A') ?><br>
          <em>Price:</em> ₱<?= htmlspecialchars($order['price'] ?? 'N/A') ?><br>
          <em>Status:</em> <?= htmlspecialchars($order['status'] ?? 'Pending') ?>
          <?php if (($order['status'] ?? '') !== 'Confirmed'): ?>
            <form action="confirm_order.php" method="POST" style="display:inline;">
              <input type="hidden" name="order_index" value="<?= $i ?>">
              <button class="confirmB" type="submit">Confirm</button>
            </form>
          <?php endif; ?>
        </li>

      <?php endforeach; ?>
    </ul>

    <!-- Display and Edit Inventory -->
    <h2>Current Inventory</h2>
    <ul class="inventory-list">
      <?php foreach ($books as $book): ?>
        <li>
          <strong><?= htmlspecialchars($book['title']) ?></strong>
          by <?= htmlspecialchars($book['author']) ?> (<?= htmlspecialchars($book['year']) ?>)

          <div class="inventory-actions">
            <!-- Update Price Form -->
            <form action="Inventory.php" method="POST">
              <input type="hidden" name="action" value="edit">
              <input type="hidden" name="book_id" value="<?= htmlspecialchars($book['bookID']) ?>">
              ₱<input
                type="number"
                name="price"
                value="<?= htmlspecialchars($book['price']) ?>"
                step="0.01"
                min="0"
                required>
              <button type="submit">Update Price</button>
            </form>

            <!-- Remove Button Form -->
            <form action="Inventory.php" method="POST">
              <input type="hidden" name="title" value="<?= htmlspecialchars($book['title']) ?>">
              <button type="submit" name="action" value="delete">Remove</button>
            </form>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>


  </div>
</body>

</html>