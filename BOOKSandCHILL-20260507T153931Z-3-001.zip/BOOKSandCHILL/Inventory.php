<?php
require_once 'utils.php';
require_once 'category.php'; // <- This includes the Category class

class Inventory {
    private $file = 'json/books.json';  // Path to JSON file

    // Function to add or delete a book from the inventory
    public function addOrDeleteBook($action, $postData) {
        // Read the current books data
        $books = read_json($this->file);

        if ($action === 'add') {
            // Generate a unique bookID
            $bookID = uniqid('book_');  // Create unique ID for the book

            // Instantiate a category object using provided category data
            $category = new Category($postData['category_id'], $postData['category_name']);

            // Add the new book to the inventory, including its category and bookID
            $books[] = [
                'bookID' => $bookID,  // Add the unique bookID
                'title' => $postData['title'],
                'author' => $postData['author'],
                'year' => $postData['year'],
                'price' => $postData['price'],
                'cover' => $postData['cover'],
                'category_id' => $category->getCategoryID(),
                'category_name' => $category->getCategoryName()
            ];
            // Path to categories file
            $categoryFile = 'json/categories.json';

            // Read existing categories
            $categories = file_exists($categoryFile) ? json_decode(file_get_contents($categoryFile), true) : [];

            // Check if category already exists by name
            $categoryExists = false;
            foreach ($categories as $cat) {
                if (strtolower($cat['category_name']) === strtolower($category->getCategoryName())) {
                    $categoryExists = true;
                    break;
                }
            }

            // If it doesn't exist, add it
            if (!$categoryExists) {
                $categories[] = [
                    'category_id' => $category->getCategoryID(),
                    'category_name' => $category->getCategoryName()
                ];
                file_put_contents($categoryFile, json_encode($categories, JSON_PRETTY_PRINT));
            }

            echo "Book '{$postData['title']}' added under category '{$category->getCategoryName()}' with bookID '{$bookID}'.<br>";
        } elseif ($action === 'delete') {
            // Remove the book from the inventory if it's to be deleted by bookID
            $books = array_filter($books, function ($book) use ($postData) {
                return $book['title'] !== $postData['title'];
            });
            $books = array_values($books);  // Re-index the array
            echo "Book '{$postData['title']}' deleted.<br>";
        }

        // Save the updated books data back to the JSON file
        write_json($this->file, $books);

        // Redirect to employee dashboard after the operation is complete
        header("Location: employee_dashboard.php");
        exit();  // Make sure script stops after the redirect
    }

    // Function to manage the quantity of a book
    public function manageQuantityOfBooks($title, $quantity) {
        $books = read_json($this->file);

        foreach ($books as &$book) {
            if ($book['title'] === $title) {
                $book['quantity'] = $quantity;
                echo "Quantity of '{$title}' updated to {$quantity}.<br>";
            }
        }

        write_json($this->file, $books);
    }

    public function editBook($postData) {
        $books = read_json($this->file);
        $updated = false;

        foreach ($books as &$book) {
            if ($book['bookID'] === $postData['book_id']) {
                $book['price'] = $postData['price'];
                $updated = true;
                break;
            }
        }

        if ($updated) {
            write_json($this->file, $books);
            echo "Book '{$postData['book_id']}' price updated to {$postData['price']}.<br>";
        } else {
            echo "Book ID '{$postData['book_id']}' not found.<br>";
        }

        header("Location: employee_dashboard.php");
        exit();
    }


}

// Handling the POST request
// Handling the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inventory = new Inventory();
    $action = $_POST['action'] ?? null;

    // Handle the uploaded cover image
    $coverFileName = '';
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'images/';
        $originalName = basename($_FILES['cover']['name']);
        $targetPath = $uploadDir . $originalName;

        if (move_uploaded_file($_FILES['cover']['tmp_name'], $targetPath)) {
            $coverFileName = $originalName;
        } else {
            echo "Error uploading cover image.";
            exit();
        }
    }

    $postData = [
        'book_id' => $_POST['book_id'] ?? '',
        'title' => $_POST['title'] ?? '',
        'author' => $_POST['author'] ?? '',
        'year' => $_POST['year'] ?? '',
        'price' => $_POST['price'] ?? '',
        'cover' => $coverFileName, // <- Use uploaded file name
        'category_id' => $_POST['category_id'] ?? '',
        'category_name' => $_POST['category_name'] ?? ''
    ];

    if ($action === 'add' || $action === 'delete') {
        $inventory->addOrDeleteBook($action, $postData);
    } elseif ($action === 'edit') {
        $inventory->editBook($postData);
    }
}

?>