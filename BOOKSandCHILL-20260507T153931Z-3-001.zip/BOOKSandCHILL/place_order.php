<?php
session_start();
require_once 'utils.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = $_SESSION['user']['name'] ?? 'Guest';
    $title = $_POST['title'] ?? '';
    $address = $_POST['address'] ?? '';
    $price = $_POST['price'] ?? 0;
    $bookID = $_POST['bookID'] ?? '';

    $customers = read_json('json/customers.json') ?? [];
    $customerID = '';
    foreach ($customers as $cust) {
        if ($cust['name'] === $customerName) {
            $customerID = $cust['customerID'];
            break;
        }
    }

    if ($title && $address && $price && $bookID && $customerID) {
        $orders = read_json('json/orders.json') ?? [];
        $orders[] = [
            'title' => $title,
            'bookID' => $bookID,
            'customer' => $customerName,
            'customerID' => $customerID,
            'address' => $address,
            'price' => $price,
            'payment' => 'Cash on Delivery',
            'status' => 'Pending',
            'date' => date('Y-m-d H:i:s')
        ];
        write_json('json/orders.json', $orders);

        // Remove from cart
        $cart = read_json('json/cart.json') ?? [];
        $cart = array_filter($cart, function($item) use ($title, $customerName, $bookID) {
            return !($item['title'] === $title && $item['customer'] === $customerName && $item['bookID'] === $bookID);
        });
        write_json('json/cart.json', array_values($cart));
    }

    header("Location: customer_dashboard.php");
    exit();
}
?>
