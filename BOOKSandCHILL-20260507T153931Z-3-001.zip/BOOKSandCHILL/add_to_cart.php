<?php
session_start();
require_once 'utils.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = $_SESSION['user']['name'] ?? 'Guest';
    $title = $_POST['title'] ?? '';
    $price = $_POST['price'] ?? 0;
    $bookID = $_POST['bookID'] ?? '';

    if ($title && $price && $bookID) {
        $cart = read_json('json/cart.json');
        if (!is_array($cart)) $cart = [];

        $cart[] = [
            'title' => $title,
            'price' => $price,
            'customer' => $customerName,
            'bookID' => $bookID,
            'date' => date('Y-m-d H:i:s'),
        ];
        write_json('json/cart.json', $cart);
    }
    // Check if already in cart
    $alreadyInCart = false;
    foreach ($cart as $item) {
        if ($item['bookID'] === $bookID && $item['customer'] === $customerName) {
            $alreadyInCart = true;
            break;
        }
    }

    if (!$alreadyInCart) {
        $cart[] = [
            'title' => $title,
            'price' => $price,
            'customer' => $customerName,
            'bookID' => $bookID,
            'date' => date('Y-m-d H:i:s'),
        ];
        write_json('json/cart.json', $cart);
    }

    header("Location: customer_dashboard.php");
    exit();
}
