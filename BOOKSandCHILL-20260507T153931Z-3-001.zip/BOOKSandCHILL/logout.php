<?php
session_start();
require_once 'User.php'; // Include the User class

// Instantiate the User class and call the logout method
$user = new User('', '', '', '', '', ''); // You can pass empty strings since we're not using these for logout
$user->logout();
?>
