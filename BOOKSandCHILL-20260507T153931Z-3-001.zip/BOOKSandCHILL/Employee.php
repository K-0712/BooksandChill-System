<?php
require_once 'User.php';
require_once 'Inventory.php';
require_once 'utils.php';

class Employee extends User {
    private $employeeID;
    private $employeeFile = 'json/employees.json';

    public function __construct($password, $name) {
        parent::__construct(null, $password, $name); // Pass null for username since it's unused
        $this->employeeID = $this->loadOrCreateEmployeeID();
    }

    private function loadOrCreateEmployeeID() {
    $employees = read_json($this->employeeFile);

    // Check if employee already exists by name and password
    foreach ($employees as $employee) {
        if ($employee['name'] === $this->name && $employee['password'] === $this->password) {
            return $employee['employeeID'];
        }
    }

    // If not found, create new employeeID
    $newID = uniqid('emp_');
    $employees[] = [
        'name' => $this->name,
        'password' => $this->password, // Store password for later verification
        'employeeID' => $newID
    ];

    write_json($this->employeeFile, $employees);
    return $newID;
}


    public function getEmployeeID() {
        return $this->employeeID;
    }

    public function manageInventory($action, $bookData) {
        $inventory = new Inventory();
        $inventory->addOrDeleteBook($action, $bookData);
    }

    public function confirmOrders($orderIndex) {
        $orders = read_json('json/orders.json');

        if (isset($orders[$orderIndex])) {
            $orders[$orderIndex]['status'] = "Confirmed";
            $orders[$orderIndex]['confirmedBy'] = $this->employeeID; // Optional tracking
            write_json('json/orders.json', $orders);
        }

        header("Location: employee_dashboard.php");
        exit();
    }
}
?>
