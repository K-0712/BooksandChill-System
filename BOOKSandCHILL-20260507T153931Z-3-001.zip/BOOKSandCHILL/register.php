<?php
session_start();
require_once 'User.php'; // Include the User class

// Call the handleRegistration method to process the form
User::handleRegistration();
?>
