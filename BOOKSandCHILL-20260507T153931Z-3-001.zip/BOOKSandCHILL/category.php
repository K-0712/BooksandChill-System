<?php
class Category {
    private $category_ID;
    private $category_name;

    public function __construct($id, $name) {
        $this->category_ID = $id;
        $this->category_name = $name;
    }

    public function getCategoryName() {
        return $this->category_name;
    }

    public function getCategoryID() {
        return $this->category_ID;
    }
}
