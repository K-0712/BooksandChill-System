<?php
require_once 'utils.php';

$orders = read_json('json/orders.json');  // Corrected path to JSON file
$index = $_POST['order_index'];

if (isset($orders[$index])) {
    $orders[$index]['status'] = "Confirmed";
    write_json('json/orders.json', $orders);  // Corrected path to JSON file
}

header("Location: employee_dashboard.php");
exit();
?>
